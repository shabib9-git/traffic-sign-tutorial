Put images for the tutorial in this folder.
