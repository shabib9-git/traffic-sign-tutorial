Put your MP3 audio notes in this folder.
